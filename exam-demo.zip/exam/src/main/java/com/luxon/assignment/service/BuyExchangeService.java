//package com.luxon.assignment.service;
//
//import com.luxon.assignment.repository.AccountRepository;
//import lombok.RequiredArgsConstructor;
//import org.springframework.stereotype.Service;
//
//@Service
//public class BuyExchangeService extends ExchangeService {
//    private final AccountRepository accountRepository;
//
//    public BuyExchangeService(AccountRepository accountRepository) {
//        super(accountRepository);
//        this.accountRepository = accountRepository;
//    }
//}
