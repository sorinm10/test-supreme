package com.luxon.assignment.service;

import com.luxon.assignment.dto.ExchangeRequestDto;
import com.luxon.assignment.repository.AccountRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
public class SendExchangeService extends ExchangeService {
    private final AccountRepository accountRepository;

    public SendExchangeService(AccountRepository accountRepository) {
        super(accountRepository);
        this.accountRepository = accountRepository;
    }
    @Override
    public boolean send(ExchangeRequestDto exchangeRequestDto) {
        return true;
    }
}
