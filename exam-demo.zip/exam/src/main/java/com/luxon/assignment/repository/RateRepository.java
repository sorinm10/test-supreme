package com.luxon.assignment.repository;

import com.luxon.assignment.entity.Account;
import com.luxon.assignment.entity.Rate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface RateRepository extends JpaRepository<Rate,Integer> {
       Optional<Rate> findByRequestTypeEqualsAndInstrumentEquals(String requestType, String Instrument);
}
