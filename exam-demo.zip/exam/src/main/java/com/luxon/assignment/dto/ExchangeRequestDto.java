package com.luxon.assignment.dto;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class ExchangeRequestDto {

    @NotNull
    private Integer accountId;

    @NotNull
    private ExchangeType exchangeType;

    private String fromCurrency;

    private String toCurrency;

    private double amount;

    //TODO - add more relevant fields here for some generic request

    enum ExchangeType {
        BUY("BUY"),SELL("SELL"),SEND("SEND");

        private String value;

        ExchangeType(String value){
            this.value = value;
        }

        public String getValue(){
            return value;
        }
    }
}
