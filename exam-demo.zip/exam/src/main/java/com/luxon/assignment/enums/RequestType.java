package com.luxon.assignment.enums;

public enum RequestType {
    BUY, SELL;


}
