package com.luxon.assignment.entity;

import com.luxon.assignment.enums.Instrument;
import com.luxon.assignment.enums.RequestType;
import lombok.Data;

import javax.persistence.*;

@Entity
@Data
public class Rate {

    @Id
    @Column
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;

    @Enumerated(value = EnumType.STRING)
    private RequestType requestType;

//    private double sellingRate;
//
//    private double buyingRate;

    @Enumerated(value = EnumType.STRING)
    private Instrument instrument;

    private Double value;
}
