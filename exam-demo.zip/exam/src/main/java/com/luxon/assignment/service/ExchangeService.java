package com.luxon.assignment.service;

import com.luxon.assignment.dto.ExchangeRequestDto;
import com.luxon.assignment.entity.Account;
import com.luxon.assignment.entity.Balance;
import com.luxon.assignment.enums.RequestType;
import com.luxon.assignment.repository.AccountRepository;
import com.luxon.assignment.repository.RateRepository;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Synchronized;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.Collections;
import java.util.List;

@Service
@RequiredArgsConstructor
public abstract class ExchangeService {

    private final AccountRepository accountRepository;

    private final RateRepository rateRepository;

    @Synchronized
    public ResponseEntity<?> execute(ExchangeRequestDto exchangeRequestDto) {
            rateRepository.
                    findByRequestTypeEqualsAndInstrumentEquals(exchangeRequestDto.getExchangeType().getValue(), exchangeRequestDto.getToCurrency());
        return ResponseEntity.ok(200);
    }

    @PostConstruct
    public void doSome() {
        Account account = accountRepository.save(Account.builder().id(1).name("Jack Black").build());
        List<Balance> userBalance = Collections.singletonList(Balance.builder().account(account).build());
        account.setBalances(userBalance);
    }

    protected abstract boolean send(ExchangeRequestDto exchangeRequestDto);

   // protected abstract boolean buy(ExchangeRequestDto exchangeRequestDto);

  //  protected abstract boolean sell(ExchangeRequestDto exchangeRequestDto);
}
